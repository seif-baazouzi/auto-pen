<?php
$conn = mysqli_connect("127.0.0.1", "devuser", "dev123", "sample");
