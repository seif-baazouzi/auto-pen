#!/bin/bash

php -S 172.17.0.1:8000
