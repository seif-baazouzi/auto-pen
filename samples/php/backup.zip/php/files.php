<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Files</title>
</head>
<body>
  <h1>Files list</h1>
  <ul>
    <li><a href="/read.php?title=File1&file=file1.txt">File1</a></li>
    <li><a href="/read.php?title=File2&file=file2.txt">File2</a></li>
    <li><a href="/read.php?title=File3&file=file3.txt">File3</a></li>
  </ul>
</body>
</html>