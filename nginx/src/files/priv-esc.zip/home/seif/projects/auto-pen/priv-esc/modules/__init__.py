from .sudo import sudoResults
from .suids import suidsResults
from .kernel import kernelResults
from .passwd import passwdResults
from .shadow import shadowResults
from .sudoers import sudoersResults
